@org.junit.Before
public void init() {
  ${BODY}
}